<?php
include('conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fields = json_decode($_POST['fields'], true);

    // حذف الحقول القديمة
    $conn->query("DELETE FROM form_fields");

    foreach ($fields as $field) {
        $field_type = $field['type'];
        $field_label = $conn->real_escape_string($field['label']);

        $sql = "INSERT INTO form_fields (field_type, field_label) VALUES ('$field_type', '$field_label')";
        $conn->query($sql);
    }

    echo "<script type='text/javascript'>alert('Form saved successfully!');</script>";
}
?>
